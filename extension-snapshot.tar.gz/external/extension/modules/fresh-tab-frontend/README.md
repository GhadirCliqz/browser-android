# Fresh-tab


## Installation

* `npm install`
* `npm install -g bower`
* `bower install`
* `npm install -g ember-cli`


## Running / Development

* `ember server`
* Visit your app at [http://localhost:4200](http://localhost:4200).


### Building

* `npm run build` (see package.json/scripts/build - creates the app in /dist folder)

